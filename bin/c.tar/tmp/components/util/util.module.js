'use strict';

angular.module('mapboxAviationDemoApp.util', []);
//# sourceMappingURL=util.module.js.map
