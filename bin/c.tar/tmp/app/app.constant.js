"use strict";

(function (angular, undefined) {
	angular.module("mapboxAviationDemoApp.constants", []).constant("appConfig", {
		"userRoles": ["guest", "user", "admin"]
	});
})(angular);
//# sourceMappingURL=app.constant.js.map
